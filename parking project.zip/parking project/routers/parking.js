const router = require('express').Router()
const regc = require('../controllers/regcontroller')
const parkingc = require('../controllers/parkingcontroller')
const logincheck = require('../helper/logincheck')

router.get('/', regc.loginform)
router.post('/', regc.logincheck)
router.get('/dashboard', logincheck, regc.dashboard)
router.get('/logout', regc.logout)
router.get('/add', parkingc.addform)
router.post('/add', parkingc.parkinginsert)
router.get('/out', parkingc.selection)
router.get('/update/:id', parkingc.calculation)
router.get('/print/:id', parkingc.print)
router.post('/out', parkingc.search)


module.exports = router