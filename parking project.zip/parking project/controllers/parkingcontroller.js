const Parking = require('../models/parking')

exports.addform = (req, res) => {
    const username = req.session.username
    res.render('addform.ejs', { username, message: '' })
}
exports.parkinginsert = (req, res) => {
    const username = req.session.username
    const { vno, vtype } = req.body
    const record = new Parking({ vno: vno, vtype: vtype })
    record.save()
    res.render('addform.ejs', { username, message: 'Successfully Added' })
}
exports.selection = async (req, res) => {
    const username = req.session.username
    const record = await Parking.find().sort({ status: -1 })
    const parked = await Parking.find({ status: 'Parked' })
    res.render('out.ejs', { username, record, parked })
}
exports.calculation = async (req, res) => {
    const id = req.params.id
    let outtime = new Date()
    const record = await Parking.findById(id)
    let totaltimespend = (outtime - record.vin) / (1000 * 60 * 60)
    //console.log(totaltimespend)
    let amount = null
    if (record.vtype == '2w') {
        amount = totaltimespend * 30
    } else if (record.vtype == '3w') {
        amount = totaltimespend * 50
    } else if (record.vtype == '4w') {
        amount = totaltimespend * 80
    } else if (record.vtype == 'hw') {
        amount = totaltimespend * 150
    } else if (record.vtype == 'lw') {
        amount = totaltimespend * 120
    } else {
        amount = totaltimespend * 70
    }
    if (amount <= 20) {
        amount = 20
    }
    await Parking.findByIdAndUpdate(id, { vout: outtime, amount: Math.round(amount), status: 'OUT' })
    res.redirect('/out')
}
exports.print = async (req, res) => {
    const id = req.params.id
    const record = await Parking.findById(id)
    res.render('print.ejs', { record })
}
exports.search = async (req, res) => {
    const { search } = req.body
    const username = req.session.username
    const record = await Parking.find({ vno: search }).sort({ status: -1 })
    const parked = await Parking.find({ status: 'Parked' })
    res.render('out.ejs', { username, record, parked })
}