const Reg = require('../models/reg')

exports.loginform = (req, res) => {
    res.render('login.ejs', { message: '' })
}
exports.logincheck = async (req, res) => {
    const { username, password } = req.body
    const record = await Reg.findOne({ username: username })
    if (record !== null) {
        if (record.password == password) {
            req.session.username = username
            req.session.isAuth = true
            res.redirect('/dashboard')
        } else {
            res.render('login.ejs', { message: 'Wrong Credentials' })
        }
    } else {
        res.render('login.ejs', { message: 'Wrong Credentials' })
    }
}
exports.dashboard = (req, res) => {
    const username = req.session.username
    res.render('dashboard.ejs', { username })
}
exports.logout = (req, res) => {
    req.session.destroy()
    res.redirect('/')
}