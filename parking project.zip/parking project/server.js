const express = require('express')
const app = express()
require('dotenv').config()
app.use(express.urlencoded({ extended: false }))
const parkinRrouter = require('./routers/parking')
const mongoose = require('mongoose')
const session = require('express-session')
mongoose.connect(`${process.env.DB_URL}/${process.env.DB_NAME}`)


app.use(session({
    secret: process.env.KEY,
    saveUninitialized: false,
    resave: false,
    //cookie:{maxAge:1000*60*60*365}
}))
app.use(parkinRrouter)
app.use(express.static('public'))
app.set('view ingine', 'ejs')
app.listen(process.env.PORT, () => { console.log(`conected to port ${process.env.PORT}`) })